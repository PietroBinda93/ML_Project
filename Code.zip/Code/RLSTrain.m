function w1 = RLSTrain(Xtr, Ytr1, lambda)
	n = size(Xtr,1);
    d = size(Xtr,2);
    
    w1 = (Xtr'*Xtr + lambda*n*eye(d))\Xtr'*Ytr1;
end


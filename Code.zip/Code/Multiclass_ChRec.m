%% CHORD_MULTICLASS

% importo i file di testing
[filenames, pathname, filterindex] = uigetfile( '*.wav', 'WAV-files (*.wav)', 'Pick a file', 'MultiSelect', 'on');
index = length(filenames);
Xtr= []; % inizializzazione matrice di training

for k = 1:index
    fullname = char(filenames(1,k));
    fs = 44100;
    [y] = audioread(fullname);
    y = y(:,1);
    L = length(y);

% trasformazione nel dominio delle frequenze
    Y = fft(y,L);
    F = ((0:1/L:1-1/L)*fs).';
    magnitudeY = abs(Y);

% limito le frequenze di interesse da 75Hz a 490Hz (considero solo due ottave)
    Ylp = Y(F<=490 & F>=75);
    newL = length(Ylp);
    newF = F(F<=490 & F>=75);

% trovo i primi tre picchi corrispondenti alle armoniche
% delle note che vengono suonate nell'accordo

    [pks,freq]= findpeaks(abs(Ylp),newF,'NPeaks',3,'MinPeakHeight',160,...
                                                  'MinPeakDistance',5);
    vars = freq'; % vettore riga con le tre armoniche principali
    Xtr= [Xtr;vars]; % riempio la matrice di training
end

% inizializzazione della matrice (nxT) di training output Multiclass
% a seconda dell'accordo troveremo un 1 nella prima o nella seconda o nella
% terza colonna della matrice e cos� via
Mytr = [1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;
    1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;
    -1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;
    -1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;
    -1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;
    -1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;
    -1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;
    -1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;];

% importo file di testing

[filenames, pathname, filterindex] = uigetfile( '*.wav', 'WAV-files (*.wav)', 'Pick a file', 'MultiSelect', 'on');
index = length(filenames);
Xts= []; % inizializzazione matrice di testing

for k = 1:index
    fullname = char(filenames(1,k));
    fs = 44100;
    [y] = audioread(fullname);
    y = y(:,1);
    L = length(y);

    Y = fft(y,L);
    F = ((0:1/L:1-1/L)*fs).';
    magnitudeY = abs(Y);

    Ylp = Y(F<=490 & F>=75);
    newL = length(Ylp);
    newF = F(F<=490 & F>=75);

    [pks,freq]= findpeaks(abs(Ylp),newF,'NPeaks',3,'MinPeakHeight',160,...
                                                  'MinPeakDistance',5);
    vars = freq'; 
    Xts= [Xts;vars];
end

% inizializzazione matrice output di testing
Myts= [1 -1 -1 -1;1 -1 -1 -1;1 -1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;-1 1 -1 -1;
    -1 -1 1 -1;-1 -1 1 -1;-1 -1 1 -1;-1 -1 -1 1;-1 -1 -1 1;-1 -1 -1 1;];
Mypred = []; % inizializzazione matrice predizioni output

Nt = 12; %numero di punti nel test set

%% KNN MULTICLASS
% approccio uno contro tutti

k = 3;
t = 4; % numero delle classi
Ytr1 = [];
for h = 1:t
    Ytr1 = Mytr(:,h);
    Ypred1 = kNNMultiClass( Xtr , Ytr1 , Xts , k );
    Mypred = [Mypred,Ypred1];
end

testing_label = [];
training_label = [];
pred_label = []; % inizializzazione vettore label delle classi
x = 1;
for b = 1:t
    for v = 1:length(Mypred)
        if (Mypred(v,b)== 1)
        pred_label = [pred_label;x];
        end
        if (Myts(v,b)== 1)
        testing_label = [testing_label;x];
        end
    end
    for j = 1:length(Mytr)
        if (Mytr(j,b)== 1)
        training_label = [training_label;x];
        end
    end
    x = x+1;
end

% plotting training data
figure;
scatter3(Xtr(:,1),Xtr(:,2),Xtr(:,3),45,training_label,'filled','MarkerEdgeColor','k');
title('MultiLabel Training Data');

% plotting predicted data
cor_x = Xts(:,1);
cor_y = Xts(:,2);
cor_z = Xts(:,3);
figure;
scatter3(cor_x,cor_y,cor_z,45,pred_label,'filled','MarkerEdgeColor','k');
title('KNN MultiLabel Prediction');

% calcolo dell'errore nel KNN
count_err = 0;
for i = 1:length(Mypred)
    if(pred_label(i)~= testing_label(i))
       count_err = count_err + 1;  
    end
end
KNN_MC_error = count_err/Nt;

%% RLS MULTICLASS
% approccio "uno contro tutti"

lambda = 0.01;
W = []; % matrice dei coefficienti
MypredRLS = []; % matrice delle predizioni con RLS
t = 4; % numero delle classi
Ytr1 = [];
w1 = [];
for j=1:t
    Ytr1= Mytr(:,j);
    w1 = RLSTrain(Xtr, Ytr1, lambda);
    W = [W,w1];  
end
MypredRLS = RLSTest(W, Xts);






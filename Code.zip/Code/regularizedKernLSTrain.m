function c = regularizedKernLSTrain(Xtr, Ytr, kernel, sigma, lambdaKer)

    n = size(Xtr,1);
    K = KernelMatrix(Xtr, Xtr, kernel, sigma);
    c = (K + lambdaKer*n*eye(n,n))\Ytr;
    
end

function YpredKer = regularizedKernLSTest(c, Xtr, kernel, sigma, Xts)

    Ktest = KernelMatrix(Xts, Xtr, kernel, sigma);
    YpredKer = Ktest*c;
    
end


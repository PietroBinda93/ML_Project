function Ypred1 = kNNMultiClass( Xtr , Ytr1 , Xts , k )

    n = size(Xtr,1);
    m = size(Xts,1);
        
    if k > n
        k = n;
    end
    
    Ypred1 = zeros(m,1);

    DistMat = SquareDist(Xtr, Xts);
   
    for j= 1:m
        SortdDistMat = DistMat(:,j);
        
        [~, I] = sort(SortdDistMat);
        idx = I(1:k);
        val = sum(Ytr1(idx))/k;

        Ypred1(j) = sign(val);
    end
end


function [k, Vm, Vs, Tm, Ts] = holdoutCVkNN(Xtr, Ytr, perc, nrip, intK)
% X: the dataset (test set excluded)
% Y: the labels (test set excluded)
% perc: percentage of the dataset to be used for validation
% nrip: number of repetitions of the test for each couple of parameters
% intK: list of regularization parameters 
%       for example intK = [1 3 5 7 9 11 17 21 31 41 51 71]
%
% Output:
% k: the value k in intK that minimize the mean of the
%       validation error
% Vm, Vs: mean and variance of the validation error for each couple of parameters
% Tm, Ts: mean and variance of the error computed on the training set for each couple
%       of parameters

nK = numel(intK);
 
    n = size(Xtr,1);
    ntr = ceil(n*(1-perc));
    
    Tm = zeros(1, nK);
    Ts = zeros(1, nK);
    Vm = zeros(1, nK);
    Vs = zeros(1, nK);
    
    ym = (max(Ytr) + min(Ytr))/2;
    
    ik = 0;
    for k=intK
        ik = ik + 1;
        for rip = 1:nrip
            I = randperm(n);
            Xnewtr = Xtr(I(1:ntr),:);
            Ynewtr = Ytr(I(1:ntr),:);
            Xvl = Xtr(I(ntr+1:end),:);
            Yvl = Ytr(I(ntr+1:end),:);

            trError =  calcErr(kNNClassify(Xnewtr, Ynewtr, Xnewtr, k),Ynewtr, ym);
            Tm(1, ik) = Tm(1, ik) + trError;
            Ts(1, ik) = Ts(1, ik) + trError^2;

            valError  = calcErr(kNNClassify(Xnewtr, Ynewtr, Xvl, k),Yvl, ym);
            Vm(1, ik) = Vm(1, ik) + valError;
            Vs(1, ik) = Vs(1, ik) + valError^2;

            str = sprintf('k\tvalErr\ttrErr\n%f\t%f\t%f\t%f\n', k, valError, trError);
            disp(str);
        end
    end
    
    Tm = Tm/nrip;
    Ts = Ts/nrip - Tm.^2;
    
    Vm = Vm/nrip;
    Vs = Vs/nrip - Vm.^2;
    
    idx = find(Vm <= min(Vm(:)));
    
    k = intK(idx(1));
end

function err = calcErr(T, Ytr, m)
    vT = (T >= m);
    vY = (Ytr >= m);
    err = sum(vT ~= vY)/numel(Ytr);
end




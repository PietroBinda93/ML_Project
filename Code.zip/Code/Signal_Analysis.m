%% Analisi del segnale

close all
clear
clc

% importo il file
filename = 'Cmag29.wav' ;
fs = 44100;
[y] = audioread(filename);
y = y(:,1);
L = length(y);

% analisi nel tempo
sound(y,fs)
figure
plot(y)
title ('Signal in time');

% analisi in frequenza
Y = fft(y,L);
F = ((0:1/L:1-1/L)*fs).';
magnitudeY = abs(Y);
figure
hold on
plot(F,magnitudeY);
title ('FFT module');

% analisi dei picchi delle armoniche principali
Ylp = Y(F<=490 & F>=75);
newL = length(Ylp);
newF = F(F<=490 & F>=75);

[peaks] = findpeaks(abs(Ylp),newF,'NPeaks',3,'MinPeakDistance',10,...
                                                  'MinPeakHeight',78);
en_peaks = sum(peaks);

figure
hold on
plot(newF,abs(Ylp),'b')

sum_energy = sum(Ylp);
ratioFactor = 160/sum_energy;
Dyn_edge = sum_energy*ratioFactor;

for i = 1:length(Ylp)
    if (Ylp(i)<Dyn_edge)
        Ylp(i)=0; 
    end
end
figure
hold on
plot(newF,abs(Ylp),'b')

[pks,freq]= findpeaks(abs(Ylp),newF,'NPeaks',3,'MinPeakHeight',160,...
                                                  'MinPeakDistance',5);


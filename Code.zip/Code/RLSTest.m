function MypredRLS = RLSTest(W, Xts)
     MypredRLS = Xts * W ;
end


function Ypred = kNNClassify( Xtr , Ytr , Xts , k )
% INPUT PARAMETERS
%   Xtr training input
%   Ytr training output 
%   k number of neighbours
%   Xts test input
% 
% OUTPUT PARAMETERS
%   Ypred estimated test output

    n = size(Xtr,1);
    m = size(Xts,1);
        
    if k > n
        k = n;
    end
    
    Ypred = zeros(m,1);

    DistMat = SquareDist(Xtr, Xts);
   
    for j= 1:m
        SortdDistMat = DistMat(:,j);
        
        [~, I] = sort(SortdDistMat);
        idx = I(1:k);
        val = sum(Ytr(idx))/k;

        Ypred(j) = sign(val);
    end
end


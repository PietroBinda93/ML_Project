function w = regularizedLSTrain(Xtr, Ytr, lambda)
	n = size(Xtr,1);
    d = size(Xtr,2);
    
    w = (Xtr'*Xtr + lambda*n*eye(d))\Xtr'*Ytr;
end


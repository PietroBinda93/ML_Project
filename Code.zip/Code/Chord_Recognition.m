%% CHORD RECOGNITION

% importo i file di testing
[filenames, pathname, filterindex] = uigetfile( '*.wav', 'WAV-files (*.wav)', 'Pick a file', 'MultiSelect', 'on');
index = length(filenames);
Xtr= []; % inizializzazione matrice di training

for k = 1:index
    fullname = char(filenames(1,k));
    fs = 44100;
    [y] = audioread(fullname);
    y = y(:,1);
    L = length(y);

% trasformazione nel dominio delle frequenze
    Y = fft(y,L);
    F = ((0:1/L:1-1/L)*fs).';
    magnitudeY = abs(Y);

% limito le frequenze di interesse da 75Hz a 490Hz (considero solo due ottave)
    Ylp = Y(F<=490 & F>=75);
    newL = length(Ylp);
    newF = F(F<=490 & F>=75);

% trovo i primi tre picchi corrispondenti alle armoniche
% delle note che vengono suonate nell'accordo con una soglia fissa

    [pks,freq]= findpeaks(abs(Ylp),newF,'NPeaks',3,'MinPeakHeight',...
                                            150,'MinPeakDistance',5);
    vars = freq'; % vettore riga con le tre armoniche principali
    Xtr= [Xtr;vars]; % riempio la matrice di training
end

% inizializzazione del vettore di training output
% la label 1 indica il C maggiore mentre la label -1 il A maggiore 
Ytr = [-1;-1;-1;-1;-1;-1;-1;-1;-1;-1;-1;-1;-1;-1;-1;-1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1];


% importo file di testing

[filenames, pathname, filterindex] = uigetfile( '*.wav', 'WAV-files (*.wav)', 'Pick a file', 'MultiSelect', 'on');
index = length(filenames);
Xts= []; % inizializzazione matrice di testing

for k = 1:index
    fullname = char(filenames(1,k));
    fs = 44100;
    [y] = audioread(fullname);
    y = y(:,1);
    L = length(y);

    Y = fft(y,L);
    F = ((0:1/L:1-1/L)*fs).';
    magnitudeY = abs(Y);

    Ylp = Y(F<=490 & F>=75);
    newL = length(Ylp);
    newF = F(F<=490 & F>=75);
   
    [pks,freq]= findpeaks(abs(Ylp),newF,'NPeaks',3,'MinPeakHeight',...
                                            150,'MinPeakDistance',5);
    vars = freq'; 
    Xts= [Xts;vars];
end

% inizializzazione vettore output di testing
Yts= [-1;-1;-1;-1;1;1;1;1;1;1];
Ypred = []; % inizializzazione vettore predizioni output
Nt = 10; % numero di punti del Test Set;

%% classificazione con KNN

k = 1; % parametro k dell'algoritmo KNN
Ypred = kNNClassify( Xtr , Ytr , Xts , k );

figure; % plotting training Set
scatter3(Xtr(:,1),Xtr(:,2),Xtr(:,3),40,Ytr,'filled','MarkerEdgeColor','k');
title('Training Set');
xlabel('Frequency(Hz)');
ylabel('Frequency(Hz)');
zlabel('Frequency(Hz)');
figure; % plotting Test Set
scatter3(Xts(:,1),Xts(:,2),Xts(:,3),40,Yts,'filled','MarkerEdgeColor','k');
hold on
sel = (Ypred ~= Yts);
scatter3(Xts(sel,1),Xts(sel,2),Xts(sel,3),300,Yts(sel),'x');
title('KNN Binary Classification');

% calcolo dell'errore nel KNN
KNN_error = sum(Ypred~=Yts)/Nt;

% Cross-Validation per KNN
intK = [0 1 3 5 7 9];
[k, Vm, Vs, Tm, Ts] = holdoutCVkNN(Xtr, Ytr, 0.2, 5, intK);
figure;
errorbar(intK, Vm, sqrt(Vs), 'b');
hold on
errorbar(intK, Tm, sqrt(Ts), 'r');

%% classificazione con Regularized Least Squares

lambda = 0.01;
YpredRLS = [];
w = regularizedLSTrain(Xtr, Ytr, lambda);
YpredRLS = regularizedLSTest(w, Xts);

% plotting Test Set and Prediction
figure;
scatter3(Xts(:,1),Xts(:,2),Xts(:,3),40,Yts,'filled','MarkerEdgeColor','k');
hold on
sel = (sign(YpredRLS) ~= Yts);
scatter3(Xts(sel,1),Xts(sel,2),Xts(sel,3),300,Yts(sel),'x'); 
title('RLS Binary Classification');
hold off

% calcolo degli errori nel RLS
RLS_error= sum(sign(YpredRLS)~=Yts)/Nt; 

% Cross-Validation per RLS
intLambda = [0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001, 0.0005, 0.0002, 0.0001];
[lambda, Vm, Vs, Tm, Ts] = holdoutCVRLS(Xtr, Ytr, 0.2, 10, intLambda);
figure;
plot(intLambda, Vm, 'b');
hold on
plot(intLambda, Tm, 'r');

%% classificazione con Kernel

YpredKer = [];
lambdaKer = 1;
sigma = 3;
kernel = 'gaussian';

c = regularizedKernLSTrain(Xtr, Ytr, kernel, sigma, lambdaKer);
YpredKer = regularizedKernLSTest(c, Xtr, kernel, sigma, Xts);

% plotting Test Set and Prediction
figure;
scatter3(Xts(:,1),Xts(:,2),Xts(:,3),40,Yts,'filled','MarkerEdgeColor','k');
hold on
sel = (sign(YpredKer) ~= Yts);
scatter3(Xts(sel,1),Xts(sel,2),Xts(sel,3),300,Yts(sel),'x'); 
title('Kernel Binary Classification');
hold off
% calcolo degli errori con Kernel Regularization
Ker_error= sum(sign(YpredKer)~=Yts)/Nt;

% Cross-Validation per Kernel Regularization

% intKerPar = [10,7,5,4,3,2.5,2.0,1.5,1.0,0.7,0.5,0.3,0.2,0.1, 0.05, 0.03,0.02, 0.01]
% intLambda = [5,2,1,0.7,0.5,0.3,0.2,0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001, 0.0005, 0.0002, 0.0001,0.00001,0.000001];
intLambda = [5,2,1,0.7,0.5,0.3,0.2,0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001, 0.0005, 0.0002, 0.0001,0.00001,0.000001];
intKerPar = [10,7,5,4,3,2.5,2.0,1.5,1.0,0.7,0.5,0.3,0.2,0.1, 0.05, 0.03,0.02, 0.01];
[l, s, Vm, Vs, Tm, Ts] = holdoutCVKernRLS(Xtr, Ytr,'gaussian', 0.2, 3, intLambda, intKerPar);
figure;
plot(intLambda, Vm, 'b');
hold on
plot(intLambda, Tm, 'r');

function YpredRLS = regularizedLSTest(w, Xts)
     YpredRLS = Xts * w ;
end
